import { JuiceItem } from './types';

export const CURRENCY = '₹';

export const JUICES: JuiceItem[] = [
  {
    id: '1',
    name: 'Classic Orange',
    description: '100% pure cold-pressed Valencia oranges.',
    price: 150,
    category: 'Fresh',
    image: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?auto=format&fit=crop&q=80&w=400',
    color: 'bg-orange-100 text-orange-600 border-orange-200',
    ingredients: ['Orange'],
    isAvailable: true
  },
  {
    id: '2',
    name: 'Green Detox',
    description: 'A refreshing mix of kale, green apple, cucumber, and lemon.',
    price: 220,
    category: 'Detox',
    image: 'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?auto=format&fit=crop&q=80&w=400',
    color: 'bg-green-100 text-green-600 border-green-200',
    ingredients: ['Kale', 'Green Apple', 'Cucumber', 'Lemon'],
    isAvailable: true
  },
  {
    id: '3',
    name: 'Tropical Sunset',
    description: 'Pineapple, mango, and a hint of passionfruit.',
    price: 180,
    category: 'Blends',
    image: 'https://images.unsplash.com/photo-1482049016688-2d3e1b311543?auto=format&fit=crop&q=80&w=400',
    color: 'bg-yellow-100 text-yellow-600 border-yellow-200',
    ingredients: ['Pineapple', 'Mango', 'Passionfruit'],
    isAvailable: true
  },
  {
    id: '4',
    name: 'Beet It',
    description: 'Beetroot, carrot, ginger, and apple for an energy boost.',
    price: 190,
    category: 'Detox',
    image: 'https://images.unsplash.com/photo-1622597467827-43975567ec60?auto=format&fit=crop&q=80&w=400',
    color: 'bg-red-100 text-red-600 border-red-200',
    ingredients: ['Beetroot', 'Carrot', 'Ginger', 'Apple'],
    isAvailable: true
  },
  {
    id: '5',
    name: 'Watermelon Breeze',
    description: 'Fresh watermelon with a touch of mint.',
    price: 120,
    category: 'Seasonal',
    image: 'https://images.unsplash.com/photo-1563227812-0ea4c22e6cc8?auto=format&fit=crop&q=80&w=400',
    color: 'bg-pink-100 text-pink-600 border-pink-200',
    ingredients: ['Watermelon', 'Mint'],
    isAvailable: true
  },
  {
    id: '6',
    name: 'Ginger Zinger',
    description: 'Apple, lemon, and a powerful kick of fresh ginger.',
    price: 160,
    category: 'Fresh',
    image: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&q=80&w=400',
    color: 'bg-amber-100 text-amber-600 border-amber-200',
    ingredients: ['Apple', 'Lemon', 'Ginger'],
    isAvailable: true
  }
];
