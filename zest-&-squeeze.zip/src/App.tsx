/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShoppingBasket, 
  Plus, 
  Minus, 
  X, 
  Leaf, 
  Flame, 
  Wind, 
  Sun,
  ChevronRight,
  ArrowRight,
  CheckCircle2,
  LayoutDashboard,
  Menu as MenuIcon,
  History,
  Ticket,
  CreditCard,
  Users,
  TrendingUp,
  Settings,
  LogOut,
  Check,
  Clock,
  AlertCircle,
  PackagePlus,
  BarChart3
} from 'lucide-react';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  signOut,
  User
} from 'firebase/auth';
import { 
  collection, 
  addDoc, 
  query, 
  where, 
  onSnapshot, 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc,
  serverTimestamp,
  orderBy,
  limit,
  getDocFromServer
} from 'firebase/firestore';
import { auth, db } from './firebase';
import { JUICES, CURRENCY } from './constants';
import { JuiceItem, CartItem, Order, UserProfile, WorkerData } from './types';

// --- Error Handling ---
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: any[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// --- Components ---

const ErrorBoundary = ({ children }: { children: React.ReactNode }) => {
  const [hasError, setHasError] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      if (event.error?.message?.includes('Firestore Error')) {
        setHasError(true);
        try {
          const info = JSON.parse(event.error.message.replace('Firestore Error: ', ''));
          setErrorMsg(`Database error: ${info.error} during ${info.operationType} on ${info.path}`);
        } catch {
          setErrorMsg('A database error occurred.');
        }
      }
    };
    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, []);

  if (hasError) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-red-50">
        <div className="bg-white p-8 rounded-3xl shadow-xl max-w-md text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Oops! Something went wrong</h2>
          <p className="text-gray-600 mb-6">{errorMsg}</p>
          <button 
            onClick={() => window.location.reload()}
            className="bg-brand-orange text-white px-6 py-2 rounded-full font-bold"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'customer' | 'worker'>('customer');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [menuItems, setMenuItems] = useState<JuiceItem[]>(JUICES);
  const [workersData, setWorkersData] = useState<WorkerData[]>([]);

  // --- Auth & Profile ---
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        const docRef = doc(db, 'users', u.uid);
        try {
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            setProfile(docSnap.data() as UserProfile);
            setView(docSnap.data().role === 'worker' ? 'worker' : 'customer');
          } else {
            // Default to customer for new users
            const newProfile: UserProfile = {
              uid: u.uid,
              email: u.email || '',
              role: 'customer',
              displayName: u.displayName || 'User'
            };
            await setDoc(docRef, newProfile);
            setProfile(newProfile);
            setView('customer');
          }
        } catch (e) {
          handleFirestoreError(e, OperationType.GET, 'users/' + u.uid);
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // --- Real-time Data ---
  useEffect(() => {
    if (!user) return;

    const ordersQuery = view === 'worker' 
      ? query(collection(db, 'orders'), orderBy('createdAt', 'desc'))
      : query(collection(db, 'orders'), where('userId', '==', user.uid), orderBy('createdAt', 'desc'));

    const unsubscribeOrders = onSnapshot(ordersQuery, (snapshot) => {
      const o = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
      setOrders(o);
    }, (e) => handleFirestoreError(e, OperationType.LIST, 'orders'));

    const unsubscribeMenu = onSnapshot(collection(db, 'menuItems'), (snapshot) => {
      if (!snapshot.empty) {
        const m = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as JuiceItem));
        setMenuItems(m);
      }
    }, (e) => handleFirestoreError(e, OperationType.LIST, 'menuItems'));

    const unsubscribeWorkers = onSnapshot(collection(db, 'workers'), (snapshot) => {
      const w = snapshot.docs.map(doc => ({ ...doc.data() } as WorkerData));
      setWorkersData(w);
    }, (e) => handleFirestoreError(e, OperationType.LIST, 'workers'));

    return () => {
      unsubscribeOrders();
      unsubscribeMenu();
      unsubscribeWorkers();
    };
  }, [user, view]);

  // --- Actions ---
  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (e) {
      console.error(e);
    }
  };

  const handleLogout = () => signOut(auth);

  const addToCart = (juice: JuiceItem) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === juice.id);
      if (existing) {
        return prev.map(item => 
          item.id === juice.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...juice, quantity: 1 }];
    });
  };

  const placeOrder = async () => {
    if (!user || cart.length === 0) return;
    const token = Math.floor(1000 + Math.random() * 9000).toString();
    const total = cart.reduce((s, i) => s + (i.price * i.quantity), 0);
    
    const newOrder = {
      userId: user.uid,
      userName: user.displayName || 'Customer',
      items: cart,
      total,
      status: 'pending',
      tokenNumber: token,
      createdAt: serverTimestamp()
    };

    try {
      await addDoc(collection(db, 'orders'), newOrder);
      setCart([]);
      setIsCartOpen(false);
      setActiveTab('history');
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, 'orders');
    }
  };

  const updateOrderStatus = async (orderId: string, status: Order['status']) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), { status });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, 'orders/' + orderId);
    }
  };

  const [isNewItemModalOpen, setIsNewItemModalOpen] = useState(false);

  const toggleAvailability = async (item: JuiceItem) => {
    try {
      // If it's a static item, we need to create it in Firestore first
      const docRef = doc(db, 'menuItems', item.id);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        await updateDoc(docRef, { isAvailable: !item.isAvailable });
      } else {
        await setDoc(docRef, { ...item, isAvailable: !item.isAvailable });
      }
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'menuItems/' + item.id);
    }
  };

  const addNewItem = async (item: Partial<JuiceItem>) => {
    try {
      await addDoc(collection(db, 'menuItems'), {
        ...item,
        isAvailable: true,
        color: 'bg-orange-100 text-orange-600 border-orange-200', // Default
        ingredients: item.ingredients || [],
        createdAt: serverTimestamp()
      });
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, 'menuItems');
    }
  };

  const saveWorkerData = async (data: WorkerData) => {
    try {
      await setDoc(doc(db, 'workers', data.uid), data);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'workers/' + data.uid);
    }
  };

  // --- Views ---

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-brand-cream">
      <motion.div 
        animate={{ rotate: 360 }}
        transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
        className="text-brand-orange"
      >
        <Sun size={48} />
      </motion.div>
    </div>
  );

  if (!user) return (
    <div className="min-h-screen flex items-center justify-center bg-brand-cream p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white p-10 rounded-[2.5rem] shadow-2xl max-w-md w-full text-center"
      >
        <div className="w-20 h-20 bg-brand-orange rounded-full flex items-center justify-center text-white mx-auto mb-6 shadow-lg shadow-orange-200">
          <Sun size={40} />
        </div>
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Zest & Squeeze</h1>
        <p className="text-gray-500 mb-8">Fresh juice, delivered with a smile. Please sign in to continue.</p>
        <button 
          onClick={handleLogin}
          className="w-full bg-white border-2 border-gray-100 hover:border-brand-orange hover:bg-orange-50 text-gray-700 font-bold py-4 rounded-2xl transition-all flex items-center justify-center gap-3"
        >
          <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="Google" />
          Sign in with Google
        </button>
      </motion.div>
    </div>
  );

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-brand-cream flex flex-col md:flex-row">
        {/* Sidebar */}
        <aside className="w-full md:w-64 bg-white border-r border-orange-100 flex flex-col sticky top-0 md:h-screen z-30">
          <div className="p-6 flex items-center gap-3">
            <div className="w-10 h-10 bg-brand-orange rounded-full flex items-center justify-center text-white">
              <Sun size={24} />
            </div>
            <span className="text-xl font-bold text-gray-800">Zest&Squeeze</span>
          </div>

          <nav className="flex-1 px-4 space-y-2">
            <div className="pb-4 mb-4 border-b border-gray-100">
              <p className="text-[10px] uppercase font-bold text-gray-400 px-4 mb-2">Role</p>
              <div className="flex bg-gray-50 p-1 rounded-xl">
                <button 
                  onClick={() => setView('customer')}
                  className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${view === 'customer' ? 'bg-white shadow-sm text-brand-orange' : 'text-gray-500'}`}
                >
                  Customer
                </button>
                <button 
                  onClick={() => setView('worker')}
                  className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${view === 'worker' ? 'bg-white shadow-sm text-brand-orange' : 'text-gray-500'}`}
                >
                  Worker
                </button>
              </div>
            </div>

            {view === 'customer' ? (
              <>
                <NavItem active={activeTab === 'dashboard'} icon={<LayoutDashboard size={20} />} label="Dashboard" onClick={() => setActiveTab('dashboard')} />
                <NavItem active={activeTab === 'menu'} icon={<MenuIcon size={20} />} label="Menu" onClick={() => setActiveTab('menu')} />
                <NavItem active={activeTab === 'history'} icon={<History size={20} />} label="Order History" onClick={() => setActiveTab('history')} />
                <NavItem active={activeTab === 'tokens'} icon={<Ticket size={20} />} label="My Tokens" onClick={() => setActiveTab('tokens')} />
              </>
            ) : (
              <>
                <NavItem active={activeTab === 'dashboard'} icon={<LayoutDashboard size={20} />} label="Dashboard" onClick={() => setActiveTab('dashboard')} />
                <NavItem active={activeTab === 'tokens'} icon={<Ticket size={20} />} label="Active Tokens" onClick={() => setActiveTab('tokens')} />
                <NavItem active={activeTab === 'inventory'} icon={<PackagePlus size={20} />} label="Inventory" onClick={() => setActiveTab('inventory')} />
                <NavItem active={activeTab === 'staff'} icon={<Users size={20} />} label="Staff Info" onClick={() => setActiveTab('staff')} />
                <NavItem active={activeTab === 'sales'} icon={<TrendingUp size={20} />} label="Sales & Profit" onClick={() => setActiveTab('sales')} />
              </>
            )}
          </nav>

          <div className="p-4 border-t border-gray-100">
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-2xl mb-4">
              <img src={user.photoURL || ''} className="w-10 h-10 rounded-full border-2 border-white shadow-sm" alt="" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-gray-800 truncate">{user.displayName}</p>
                <p className="text-[10px] text-gray-500 truncate capitalize">{profile?.role}</p>
              </div>
            </div>
            <button 
              onClick={handleLogout}
              className="w-full flex items-center gap-3 p-3 text-gray-500 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all font-bold text-sm"
            >
              <LogOut size={18} /> Logout
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 md:p-10 overflow-y-auto">
          <AnimatePresence mode="wait">
            {view === 'customer' ? (
              <CustomerView 
                tab={activeTab} 
                orders={orders} 
                menuItems={menuItems} 
                addToCart={addToCart} 
                cart={cart}
                setIsCartOpen={setIsCartOpen}
              />
            ) : (
              <WorkerView 
                tab={activeTab} 
                orders={orders} 
                menuItems={menuItems} 
                workersData={workersData}
                currentUser={user}
                updateStatus={updateOrderStatus}
                toggleAvailability={toggleAvailability}
                setIsNewItemModalOpen={setIsNewItemModalOpen}
                saveWorkerData={saveWorkerData}
              />
            )}
          </AnimatePresence>
        </main>

        {/* Cart Overlay */}
        <CartOverlay 
          isOpen={isCartOpen} 
          onClose={() => setIsCartOpen(false)} 
          cart={cart} 
          setCart={setCart} 
          onPlaceOrder={placeOrder} 
        />

        {/* New Item Modal */}
        {isNewItemModalOpen && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl"
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-display font-bold text-gray-900">Add New Juice</h3>
                <button onClick={() => setIsNewItemModalOpen(false)} className="p-2 hover:bg-gray-100 rounded-full">
                  <X size={24} />
                </button>
              </div>
              
              <form onSubmit={async (e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                const newItem = {
                  name: formData.get('name') as string,
                  description: formData.get('description') as string,
                  price: Number(formData.get('price')),
                  category: formData.get('category') as JuiceItem['category'],
                  image: `https://picsum.photos/seed/${formData.get('name')}/400/400`,
                  ingredients: (formData.get('ingredients') as string).split(',').map(i => i.trim()),
                };
                await addNewItem(newItem);
                setIsNewItemModalOpen(false);
              }} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                  <input name="name" required className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-orange outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea name="description" required className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-orange outline-none" rows={2} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Price (₹)</label>
                    <input name="price" type="number" required className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-orange outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <select name="category" className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-orange outline-none">
                      <option value="Fresh">Fresh</option>
                      <option value="Blends">Blends</option>
                      <option value="Detox">Detox</option>
                      <option value="Seasonal">Seasonal</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Ingredients (comma separated)</label>
                  <input name="ingredients" className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-orange outline-none" placeholder="Apple, Ginger, Lemon" />
                </div>
                <button type="submit" className="w-full bg-brand-orange text-white py-3 rounded-xl font-bold hover:bg-orange-600 transition-colors mt-4">
                  Register Item
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
}

// --- Sub-Components ---

function NavItem({ active, icon, label, onClick }: { active: boolean, icon: React.ReactNode, label: string, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all font-bold text-sm ${
        active 
        ? 'bg-brand-orange text-white shadow-lg shadow-orange-100' 
        : 'text-gray-500 hover:bg-orange-50 hover:text-brand-orange'
      }`}
    >
      {icon} {label}
    </button>
  );
}

function CustomerView({ tab, orders, menuItems, addToCart, cart, setIsCartOpen }: any) {
  const pendingOrders = orders.filter((o: any) => o.status !== 'completed' && o.status !== 'rejected');

  return (
    <motion.div
      key={tab}
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="space-y-8"
    >
      {tab === 'dashboard' && (
        <>
          <div className="flex justify-between items-end">
            <div>
              <h2 className="text-4xl font-serif italic text-gray-800">Welcome back!</h2>
              <p className="text-gray-500">What would you like to drink today?</p>
            </div>
            <button 
              onClick={() => setIsCartOpen(true)}
              className="bg-white p-4 rounded-2xl shadow-sm hover:shadow-md transition-all relative"
            >
              <ShoppingBasket className="text-brand-orange" />
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-brand-orange text-white text-[10px] font-bold w-6 h-6 rounded-full flex items-center justify-center border-4 border-white">
                  {cart.length}
                </span>
              )}
            </button>
          </div>

          {pendingOrders.length > 0 && (
            <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-orange-50">
              <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                <Clock className="text-brand-orange" size={20} /> Active Orders
              </h3>
              <div className="space-y-4">
                {pendingOrders.map((o: any) => (
                  <div key={o.id} className="flex items-center justify-between p-4 bg-orange-50 rounded-2xl">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center font-bold text-brand-orange shadow-sm">
                        #{o.tokenNumber}
                      </div>
                      <div>
                        <p className="font-bold text-gray-800 capitalize">{o.status}</p>
                        <p className="text-xs text-gray-500">{o.items.length} items • {CURRENCY}{o.total}</p>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      {['pending', 'accepted', 'preparing', 'ready'].map((s, i) => (
                        <div key={s} className={`w-2 h-2 rounded-full ${
                          ['pending', 'accepted', 'preparing', 'ready'].indexOf(o.status) >= i ? 'bg-brand-orange' : 'bg-gray-200'
                        }`} />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {menuItems.slice(0, 3).map((juice: any) => (
              <JuiceCard key={juice.id} juice={juice} onAdd={() => addToCart(juice)} />
            ))}
          </div>
        </>
      )}

      {tab === 'menu' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {menuItems.map((juice: any) => (
            <JuiceCard key={juice.id} juice={juice} onAdd={() => addToCart(juice)} />
          ))}
        </div>
      )}

      {tab === 'history' && (
        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-gray-800">Order History</h2>
          {orders.length === 0 ? (
            <p className="text-gray-500">No orders yet.</p>
          ) : (
            orders.map((o: any) => (
              <div key={o.id} className="bg-white p-6 rounded-3xl shadow-sm flex items-center justify-between">
                <div className="flex items-center gap-6">
                  <div className="text-center">
                    <p className="text-[10px] text-gray-400 uppercase font-bold">Token</p>
                    <p className="text-xl font-bold text-gray-800">#{o.tokenNumber}</p>
                  </div>
                  <div>
                    <p className="font-bold text-gray-800">{o.items.map((i: any) => i.name).join(', ')}</p>
                    <p className="text-xs text-gray-500">{new Date(o.createdAt?.seconds * 1000).toLocaleDateString()}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-gray-800">{CURRENCY}{o.total}</p>
                  <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded-md ${
                    o.status === 'completed' ? 'bg-green-100 text-green-600' : 
                    o.status === 'rejected' ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600'
                  }`}>
                    {o.status}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {tab === 'tokens' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {orders.filter((o: any) => o.status !== 'completed' && o.status !== 'rejected').map((o: any) => (
            <div key={o.id} className="bg-white p-8 rounded-[2.5rem] shadow-xl border-2 border-dashed border-orange-200 text-center relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-2 bg-brand-orange" />
              <Ticket className="text-brand-orange mx-auto mb-4" size={48} />
              <p className="text-gray-400 uppercase font-bold tracking-widest text-xs mb-2">Order Token</p>
              <h3 className="text-5xl font-bold text-gray-800 mb-6 tracking-tighter">#{o.tokenNumber}</h3>
              <div className="bg-orange-50 p-4 rounded-2xl mb-6">
                <p className="text-sm font-bold text-brand-orange uppercase">{o.status}</p>
                <p className="text-xs text-gray-500">Show this at the counter</p>
              </div>
              <div className="flex justify-center gap-2">
                {o.items.map((item: any, idx: number) => (
                  <div key={idx} className="w-8 h-8 rounded-full overflow-hidden border-2 border-white shadow-sm">
                    <img src={item.image} className="w-full h-full object-cover" alt="" />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
}

function WorkerView({ tab, orders, menuItems, workersData, currentUser, updateStatus, toggleAvailability, setIsNewItemModalOpen, saveWorkerData }: any) {
  const activeOrders = orders.filter((o: any) => o.status !== 'completed' && o.status !== 'rejected');
  const totalSales = orders.filter((o: any) => o.status === 'completed').reduce((s: number, o: any) => s + o.total, 0);
  const profit = totalSales * 0.4; // 40% profit margin
  const [isStaffModalOpen, setIsStaffModalOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<any>(null);

  return (
    <motion.div
      key={tab}
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="space-y-8"
    >
      {tab === 'dashboard' && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StatCard icon={<ShoppingBasket />} label="Active Orders" value={activeOrders.length} color="bg-blue-500" />
            <StatCard icon={<TrendingUp />} label="Total Sales" value={`${CURRENCY}${totalSales}`} color="bg-green-500" />
            <StatCard icon={<BarChart3 />} label="Est. Profit" value={`${CURRENCY}${profit.toFixed(0)}`} color="bg-orange-500" />
          </div>

          <div className="bg-white p-8 rounded-[2.5rem] shadow-sm">
            <h3 className="text-xl font-bold text-gray-800 mb-6">Recent Activity</h3>
            <div className="space-y-6">
              {orders.slice(0, 5).map((o: any) => (
                <div key={o.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center font-bold text-gray-500">
                      {o.userName[0]}
                    </div>
                    <div>
                      <p className="font-bold text-gray-800">{o.userName}</p>
                      <p className="text-xs text-gray-500">{o.items.length} items • {CURRENCY}{o.total}</p>
                    </div>
                  </div>
                  <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded-md ${
                    o.status === 'completed' ? 'bg-green-100 text-green-600' : 
                    o.status === 'rejected' ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600'
                  }`}>
                    {o.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {tab === 'tokens' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {activeOrders.map((o: any) => (
            <div key={o.id} className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-orange-50 rounded-2xl flex items-center justify-center text-2xl font-bold text-brand-orange">
                    #{o.tokenNumber}
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800">{o.userName}</h4>
                    <p className="text-xs text-gray-500 capitalize">{o.status}</p>
                  </div>
                </div>
                <p className="font-bold text-lg text-gray-800">{CURRENCY}{o.total}</p>
              </div>

              <div className="space-y-2 mb-6">
                {o.items.map((item: any, idx: number) => (
                  <div key={idx} className="flex justify-between text-sm">
                    <span className="text-gray-600">{item.quantity}x {item.name}</span>
                    <span className="text-gray-400">{CURRENCY}{item.price * item.quantity}</span>
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                {o.status === 'pending' && (
                  <>
                    <button onClick={() => updateStatus(o.id, 'accepted')} className="flex-1 bg-green-500 text-white py-3 rounded-xl font-bold text-sm hover:bg-green-600 transition-all">Accept</button>
                    <button onClick={() => updateStatus(o.id, 'rejected')} className="flex-1 bg-red-50 text-red-500 py-3 rounded-xl font-bold text-sm hover:bg-red-100 transition-all">Reject</button>
                  </>
                )}
                {o.status === 'accepted' && (
                  <button onClick={() => updateStatus(o.id, 'preparing')} className="flex-1 bg-blue-500 text-white py-3 rounded-xl font-bold text-sm hover:bg-blue-600 transition-all">Start Preparing</button>
                )}
                {o.status === 'preparing' && (
                  <button onClick={() => updateStatus(o.id, 'ready')} className="flex-1 bg-yellow-500 text-white py-3 rounded-xl font-bold text-sm hover:bg-yellow-600 transition-all">Mark Ready</button>
                )}
                {o.status === 'ready' && (
                  <button onClick={() => updateStatus(o.id, 'completed')} className="flex-1 bg-brand-orange text-white py-3 rounded-xl font-bold text-sm hover:bg-orange-600 transition-all">Complete Order</button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === 'inventory' && (
        <div className="bg-white rounded-[2.5rem] shadow-sm overflow-hidden">
          <div className="p-8 border-b border-gray-100 flex justify-between items-center">
            <h3 className="text-xl font-bold text-gray-800">Item Sales Control</h3>
            <button 
              onClick={() => setIsNewItemModalOpen(true)}
              className="bg-brand-orange text-white px-4 py-2 rounded-xl font-bold text-sm flex items-center gap-2"
            >
              <PackagePlus size={18} /> Add New Item
            </button>
          </div>
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50 text-[10px] uppercase font-bold text-gray-400 tracking-widest">
                <th className="px-8 py-4">Item</th>
                <th className="px-8 py-4">Category</th>
                <th className="px-8 py-4">Price</th>
                <th className="px-8 py-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {menuItems.map((item: any) => (
                <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-8 py-4">
                    <div className="flex items-center gap-3">
                      <img src={item.image} className="w-10 h-10 rounded-lg object-cover" alt="" />
                      <span className="font-bold text-gray-800">{item.name}</span>
                    </div>
                  </td>
                  <td className="px-8 py-4 text-sm text-gray-500">{item.category}</td>
                  <td className="px-8 py-4 font-bold text-gray-800">{CURRENCY}{item.price}</td>
                  <td className="px-8 py-4 text-right">
                    <button 
                      onClick={() => toggleAvailability(item)}
                      className={`px-4 py-1.5 rounded-full text-[10px] font-bold uppercase transition-all ${
                        item.isAvailable ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                      }`}
                    >
                      {item.isAvailable ? 'Available' : 'Sold Out'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'sales' && (
        <div className="space-y-6">
          <div className="bg-white p-8 rounded-[2.5rem] shadow-sm">
            <h3 className="text-xl font-bold text-gray-800 mb-6">Profit Calculator</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-500">Gross Revenue</span>
                  <span className="font-bold text-gray-800">{CURRENCY}{totalSales}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-500">Cost of Goods (60%)</span>
                  <span className="font-bold text-red-500">-{CURRENCY}{(totalSales * 0.6).toFixed(0)}</span>
                </div>
                <div className="h-px bg-gray-100" />
                <div className="flex justify-between items-center text-lg">
                  <span className="font-bold text-gray-800">Net Profit</span>
                  <span className="font-bold text-green-500">{CURRENCY}{profit.toFixed(0)}</span>
                </div>
              </div>
              <div className="bg-orange-50 p-6 rounded-3xl flex flex-col justify-center text-center">
                <TrendingUp className="text-brand-orange mx-auto mb-2" size={32} />
                <p className="text-2xl font-bold text-gray-800">40%</p>
                <p className="text-xs text-gray-500">Average Margin</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {tab === 'staff' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-3xl font-display font-bold text-gray-900">Staff Management</h2>
            <button 
              onClick={() => {
                setEditingStaff(null);
                setIsStaffModalOpen(true);
              }}
              className="bg-brand-orange text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-lg shadow-orange-100"
            >
              <Plus size={20} /> Add Staff Info
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {workersData.map((worker: any) => (
              <motion.div 
                key={worker.uid}
                whileHover={{ y: -5 }}
                className="bg-white p-6 rounded-[2rem] shadow-sm border border-orange-50 relative overflow-hidden group"
              >
                <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button 
                    onClick={() => {
                      setEditingStaff(worker);
                      setIsStaffModalOpen(true);
                    }}
                    className="p-2 bg-gray-50 text-gray-400 hover:text-brand-orange rounded-full"
                  >
                    <Settings size={18} />
                  </button>
                </div>
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-orange-100 rounded-2xl flex items-center justify-center text-brand-orange font-bold text-xl">
                    {worker.employeeId.slice(-2)}
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800">ID: {worker.employeeId}</h3>
                    <p className="text-xs text-gray-400 uppercase tracking-widest font-bold">{worker.shift} Shift</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Specialization</span>
                    <span className="font-bold text-gray-700">{worker.specialization}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Rating</span>
                    <span className="font-bold text-yellow-500">★ {worker.rating}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Joined</span>
                    <span className="font-bold text-gray-700">{new Date(worker.joinDate).toLocaleDateString()}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {isStaffModalOpen && (
            <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white rounded-[2.5rem] p-8 max-w-md w-full shadow-2xl"
              >
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-2xl font-display font-bold text-gray-900">
                    {editingStaff ? 'Edit Staff Info' : 'Add Staff Info'}
                  </h3>
                  <button onClick={() => setIsStaffModalOpen(false)} className="p-2 hover:bg-gray-100 rounded-full">
                    <X size={24} />
                  </button>
                </div>
                
                <form onSubmit={async (e) => {
                  e.preventDefault();
                  const formData = new FormData(e.currentTarget);
                  const data = {
                    uid: editingStaff?.uid || currentUser.uid,
                    employeeId: formData.get('employeeId') as string,
                    shift: formData.get('shift') as any,
                    specialization: formData.get('specialization') as string,
                    rating: Number(formData.get('rating')),
                    joinDate: formData.get('joinDate') as string,
                  };
                  await saveWorkerData(data);
                  setIsStaffModalOpen(false);
                }} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Employee ID</label>
                    <input name="employeeId" defaultValue={editingStaff?.employeeId} required className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-orange outline-none" placeholder="EMP-001" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Shift</label>
                      <select name="shift" defaultValue={editingStaff?.shift || 'Morning'} className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-orange outline-none">
                        <option value="Morning">Morning</option>
                        <option value="Afternoon">Afternoon</option>
                        <option value="Evening">Evening</option>
                        <option value="Night">Night</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Rating (1-5)</label>
                      <input name="rating" type="number" step="0.1" min="1" max="5" defaultValue={editingStaff?.rating || 5} required className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-orange outline-none" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Specialization</label>
                    <input name="specialization" defaultValue={editingStaff?.specialization} required className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-orange outline-none" placeholder="Master Juicer" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Join Date</label>
                    <input name="joinDate" type="date" defaultValue={editingStaff?.joinDate || new Date().toISOString().split('T')[0]} required className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-orange outline-none" />
                  </div>
                  <button type="submit" className="w-full bg-brand-orange text-white py-4 rounded-2xl font-bold hover:bg-orange-600 transition-colors mt-4 shadow-lg shadow-orange-100">
                    {editingStaff ? 'Update Info' : 'Save Info'}
                  </button>
                </form>
              </motion.div>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}

function JuiceCard({ juice, onAdd }: { juice: JuiceItem, onAdd: () => void, key?: any }) {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className={`bg-white rounded-3xl overflow-hidden shadow-sm border border-orange-50 group ${!juice.isAvailable ? 'opacity-60 grayscale' : ''}`}
    >
      <div className="relative h-48 overflow-hidden">
        <img src={juice.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt="" referrerPolicy="no-referrer" />
        {!juice.isAvailable && (
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <span className="bg-white text-gray-800 px-4 py-1 rounded-full font-bold text-xs uppercase">Sold Out</span>
          </div>
        )}
      </div>
      <div className="p-5">
        <div className="flex justify-between items-start mb-1">
          <h4 className="font-bold text-gray-800">{juice.name}</h4>
          <span className="font-bold text-brand-orange">{CURRENCY}{juice.price}</span>
        </div>
        <p className="text-xs text-gray-400 mb-4 line-clamp-1">{juice.description}</p>
        <button 
          disabled={!juice.isAvailable}
          onClick={onAdd}
          className="w-full bg-gray-50 hover:bg-brand-orange hover:text-white text-gray-700 font-bold py-2.5 rounded-xl transition-all text-sm flex items-center justify-center gap-2"
        >
          <Plus size={16} /> Add to Cart
        </button>
      </div>
    </motion.div>
  );
}

function StatCard({ icon, label, value, color }: any) {
  return (
    <div className="bg-white p-6 rounded-[2rem] shadow-sm flex items-center gap-4">
      <div className={`w-12 h-12 ${color} text-white rounded-2xl flex items-center justify-center shadow-lg shadow-gray-100`}>
        {icon}
      </div>
      <div>
        <p className="text-xs text-gray-400 font-bold uppercase tracking-wider">{label}</p>
        <p className="text-2xl font-bold text-gray-800">{value}</p>
      </div>
    </div>
  );
}

function CartOverlay({ isOpen, onClose, cart, setCart, onPlaceOrder }: any) {
  const total = cart.reduce((s: number, i: any) => s + (i.price * i.quantity), 0);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40" />
          <motion.div initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} className="fixed right-0 top-0 h-full w-full max-w-md bg-white z-50 shadow-2xl flex flex-col">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center">
              <h2 className="text-2xl font-bold flex items-center gap-2">Your Order <ShoppingBasket className="text-brand-orange" /></h2>
              <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full"><X /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center text-gray-400">
                  <ShoppingBasket size={48} className="mb-4" />
                  <p className="font-bold">Your cart is empty</p>
                </div>
              ) : (
                cart.map((item: any) => (
                  <div key={item.id} className="flex gap-4">
                    <img src={item.image} className="w-16 h-16 rounded-xl object-cover" alt="" />
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <h4 className="font-bold text-gray-800">{item.name}</h4>
                        <button onClick={() => setCart((prev: any) => prev.filter((i: any) => i.id !== item.id))}><X size={14} className="text-gray-400" /></button>
                      </div>
                      <p className="text-brand-orange font-bold text-sm">{CURRENCY}{item.price * item.quantity}</p>
                      <div className="flex items-center gap-3 mt-2">
                        <button onClick={() => setCart((prev: any) => prev.map((i: any) => i.id === item.id ? { ...i, quantity: Math.max(1, i.quantity - 1) } : i))} className="w-6 h-6 rounded-full border border-gray-200 flex items-center justify-center"><Minus size={12} /></button>
                        <span className="text-xs font-bold">{item.quantity}</span>
                        <button onClick={() => setCart((prev: any) => prev.map((i: any) => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i))} className="w-6 h-6 rounded-full border border-gray-200 flex items-center justify-center"><Plus size={12} /></button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
            {cart.length > 0 && (
              <div className="p-6 bg-gray-50 space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-500">Total</span>
                  <span className="text-2xl font-bold text-gray-800">{CURRENCY}{total}</span>
                </div>
                <button onClick={onPlaceOrder} className="w-full bg-brand-orange text-white py-4 rounded-2xl font-bold text-lg shadow-lg shadow-orange-100">Place Order</button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
