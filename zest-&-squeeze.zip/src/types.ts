export interface JuiceItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'Fresh' | 'Blends' | 'Detox' | 'Seasonal';
  image: string;
  color: string;
  ingredients: string[];
  isAvailable: boolean;
}

export interface CartItem extends JuiceItem {
  quantity: number;
}

export interface Order {
  id: string;
  userId: string;
  userName: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'accepted' | 'rejected' | 'preparing' | 'ready' | 'completed';
  tokenNumber: string;
  createdAt: any;
}

export interface UserProfile {
  uid: string;
  email: string;
  role: 'customer' | 'worker' | 'admin';
  displayName: string;
}

export interface WorkerData {
  uid: string;
  employeeId: string;
  shift: 'Morning' | 'Afternoon' | 'Evening' | 'Night';
  specialization: string;
  rating: number;
  joinDate: string;
}
